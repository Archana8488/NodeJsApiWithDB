const sequelize = require('sequelize');

//'TrainingDatabase','demo','demo123',
//'TheWellnessCornerRetail','DEV-SQLPROD','2UW25I6Z97nJA5g5D'
const connection =new sequelize('TrainingDatabase','demo','demo123',{
    host:'192.168.1.26',
    dialect:'mssql'
});

connection
    .authenticate()
    .then(()=>{
        console.log('Connection has been establish successfully');
    })
    .catch(err =>{
        console.log('unable to connect database');
    });
module.exports={
    sequelize,
    connection
}