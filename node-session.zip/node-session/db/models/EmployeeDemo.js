const {connection,sequelize} =  require('../config');


const EmployeeDemo =connection.define('EmployeeDemo',{
    //attributes
    Id:{
        type:sequelize.INTEGER,
        allowNULL:false

    },
    Name:{
        type:sequelize.STRING,
        allowNULL:true
    },
    Department:{
        type:sequelize.STRING,
        allowNULL:true 
    },
    Slary:{
        type:sequelize.INTEGER,
        allowNULL:true 
    },
    IsActive:{
        type:sequelize.BOOLEAN,
        allowNULL:true  
    },
},{
        freezeTableName: true,
        timestamps:false
    });
  

module.exports= EmployeeDemo;

// EmployeeDemo.findOne().then(function(data){
//     console.log(data.datavalues)
// });