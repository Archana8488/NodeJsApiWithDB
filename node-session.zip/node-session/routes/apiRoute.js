const express= require('express');
const router = express.Router();
const EmployeeDemo = require('../db/models/EmployeeDemo');

/**
 * @swagger
 *  /api/findOne:
 *      get:
 *          tags:
 *          - Employees
 *          summary: Get user 
 *          description: Get all employee from the json file
 *          responses:
 *            200:
 *              description: List of employee
 *              schema:
 *                type: "array"
 *                items:
 *                 properties:
 *                  Id:
 *                      type:integer
 *                  Name:
 *                    type: string
 *                  Department:
 *                    type: string
 *                  Salary:
 *                    type: integer
 *                  IsActive:
 *                    type: boolean              
 *            401:
 *              description: Bad request.
 *            404:
 *              description: Not found.
 */
router.get("/findOne",function(req,res){
    EmployeeDemo.findOne().then(function(data){
        res.send(data);
    }).catch(err=>{
        res.send(err);
    })
});

/**
 * @swagger
 *  /api/getAll:
 *     get:
 *          tags:
 *          - Employees
 *          summary: Get user 
 *          description: Get all employee from the json file
 *          responses:
 *            200:
 *              description: List of employee
 *              schema:
 *                type: "array"
 *                items:
 *                 properties:
 *                  Id:
 *                      type:integer
 *                  Name:
 *                    type: string
 *                  Department:
 *                    type: string
 *                  Salary:
 *                    type: integer
 *                  IsActive:
 *                    type: boolean              
 *            401:
 *              description: Bad request.
 *            404:
 *              description: Not found.
 */

router.get("/getAll",function(req,res){
    EmployeeDemo.findAll().then(function(data){
        res.send(data);
    }).catch(err=>{
        res.send(err);
    })
});

/**
 * @swagger
 *  /api/Create:
 *      post:
 *          tags:
 *          - Employees
 *          summary: Add User
 *          description: Add user into json
 *          parameters:       
 *           - name: body
 *             in: body
 *             schema:
 *               type: object
 *               properties:
 *                Name:
 *                  type: string
 *                Departmen:
 *                  type: string
 *                Salary:
 *                  type: Integer   
 *          responses:
 *            200:
 *              description: Employee created successfully!
 *            404:
 *              description: No Found
 *            400:
 *              description: Bad request
 *            409:
 *              description: This employee already exists
 *            500:
 *              description: Internal Server Error.
 */

router.post("/Create",function(req,res){
    let UserData= {
        Name:req.body.Name,
        Department:req.body.Department,
        Slary:req.body.Slary,
        IsActive:false
    }
    EmployeeDemo.create({
        Name:UserData.Name,
        Department:UserData.Department,
        Slary:UserData.Slary,
        IsActive:UserData.IsActive
    }).then(data=>{
        res.status(201).send({
            status:true,
            message:"successfully created !"
        })
    })
}); 

/**
 * @swagger
 *  /api/Update:
 *      put:
 *          tags:
 *          - Employees
 *          summary: Update User
 *          description: Add user into json
 *          parameters:       
 *           - name: body
 *             in: body
 *             schema:
 *               type: object
 *               properties:
 *                Id:
 *                    type:integer
 *                Name:
 *                  type: string
 *                Department:
 *                  type: string
 *                Salary:
 *                  type: integer   
 *          responses:
 *            200:
 *              description: Employee created successfully!
 *            404:
 *              description: No Found
 *            400:
 *              description: Bad request
 *            409:
 *              description: This employee already exists
 *            500:
 *              description: Internal Server Error.
 */
router.put("/Update",function(req,res){
    let UserData= {
        Id:req.body.Id,
        Name:req.body.Name,
        Department:req.body.Department,
        Slary:req.body.Slary,
        IsActive:false
    }
    EmployeeDemo.update({
        Name:UserData.Name,
        Department:UserData.Department,
        Slary:UserData.Slary,
        IsActive:UserData.IsActive
    },{where:{
        Id: UserData.Id
    }}).then(data=>{
        res.status(201).send({
            status:true,
            message:"successfully updated !"
        })
    })
});

module.exports=router;