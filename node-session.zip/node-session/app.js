const express = require('express');
const bodyParser=require('body-parser');
const swaggerJsDoc = require('swagger-jsdoc')
const swaggerUi = require('swagger-ui-express')
const app=express();

const PORT = process.env.PORT || 9000;
app.use(bodyParser.json());

const apiRoute =require("./routes/apiRoute");

app.use('/api',apiRoute);

const swaggerOptions = {
    swaggerDefinition: {
        info: {
            title: 'My Sample User API',
            description: 'My Sample User API documentation',
            contact: {
                name: 'Sample Api Doc'
            },
            servers: [`http://localhost:${PORT}`]
        }
    },
    apis: ["./routes/apiRoute.js"]
 }
 
 const swaggerDocs = swaggerJsDoc(swaggerOptions)
 app.use('/api-doc', swaggerUi.serve, swaggerUi.setup(swaggerDocs))

//app.use(bodyParser.urlencoded({extended :true}));

app.listen(PORT,function(){
    console.log("Application is running on 9000 port");
})



