const chai = require('chai');
const chaiHttp = require('chai-http');
const server = require('./app');
const should = chai.should()
chai.use(chaiHttp);

describe('Get list of user "/api/getAll"',()=>{
    it('it should return 200k',(done)=>{
        
        chai.request(server)
        .get('/api/getAll')
        .end((err,res)=>{
            res.should.have.status(200);
           should.not.exist(err);
           res.body.should.be.a('array');
            done()
        })
    });
});

describe('Add user "/api/Create"',()=>{
    it('it should return 200k',(done)=>{
        chai.request(server)
        .post('/api/Create')
        .send(
            {
                //"EmployeeID": 1,
                Name: "Priyanka Singh",
                Department: "TDD Test",
                Salary: "4500"
            }
        )
        .end((err,res)=>{
            res.should.have.status(200);
            should.not.exist(err);
            //res.body.message.should.equal('Employee Add Successfully');
            done();
        })
        //.set('','')
    })

    // it("it should return 401 OK",(dome)=>{
    //     chai.request(server)
    //         .post("/api/addNewData")
    //         .end((err,res)=>{
    //             res.should.have.status(401);
    //             done();
    //         })
    // })
})