const { sql,poolPromise } = require('../database/db')
const fs = require('fs');
var rawdata = fs.readFileSync('./query/queries.json');
var queries = JSON.parse(rawdata);

class MainController {
    async getAllStudent(req , res){
        try {
          const pool = await poolPromise
            const result = await pool.request()
            .query(queries.getAllStudent)
            res.json(result.recordset)
        } catch (error) {
          res.status(500)
          res.send(error.message)
        }
      }
}

const controller = new MainController()
module.exports = controller;