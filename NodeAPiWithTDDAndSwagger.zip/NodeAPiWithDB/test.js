const chai = require('chai');
const chaiHttp = require('chai-http');
const server = require('./index');
const should = chai.should()
chai.use(chaiHttp);

describe('Get list of user "/api/getAllData"',()=>{
    it('it should return 200k',(done)=>{
        
        chai.request(server)
        .get('/api/getAllData')
        .end((err,res)=>{
            res.should.have.status(200);
           should.not.exist(err);
           res.body.should.be.a('array');
            done()
        })
    });
});

describe('Add user "/api/addNewData"',()=>{
    it('it should return 200k',(done)=>{
        chai.request(server)
        .post('/api/addNewData')
        .send(
            {
                //"EmployeeID": 1,
                Name: "Archana Singh",
                City: "Surat",
                Department: "Information",
                Gender: "Female"
            }
        )
        .end((err,res)=>{
            res.should.have.status(200);
            should.not.exist(err);
            //res.body.message.should.equal('Employee Add Successfully');
            done();
        })
        //.set('','')
    })

    // it("it should return 401 OK",(dome)=>{
    //     chai.request(server)
    //         .post("/api/addNewData")
    //         .end((err,res)=>{
    //             res.should.have.status(401);
    //             done();
    //         })
    // })
})