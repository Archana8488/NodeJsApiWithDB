const express = require('express')
const bodyParser = require('body-parser')
 const cors = require('cors')
const fs = require('fs')
const path = require('path')
 const morgan = require('morgan')
const router = require('./routes/route')
const swaggerJsDoc = require('swagger-jsdoc')
const swaggerUi = require('swagger-ui-express')
//require('dotenv').config()
const app = express();

const PORT = process.env.PORT || 3000;

app.use(cors())


// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// parse application/json
app.use(bodyParser.json());

app.use(morgan('dev'));

// create a write stream (in append mode)
var accessLogStream = fs.createWriteStream(path.join(__dirname, '/logs/access.log'), { flags: 'a' });
 
// setup the logger
app.use(morgan('combined', { stream: accessLogStream }));

app.use(router);

app.get('/', function (req, res) {
    res.send('Hello World!')
  })

  const swaggerOptions = {
   swaggerDefinition: {
       info: {
           title: 'My Sample User API',
           description: 'My Sample User API documentation',
           contact: {
               name: 'Sample Api Doc'
           },
           servers: [`http://localhost:${PORT}`]
       }
   },
   apis: ["./routes/route.js"]
}

const swaggerDocs = swaggerJsDoc(swaggerOptions)
app.use('/api-doc', swaggerUi.serve, swaggerUi.setup(swaggerDocs))

//const port = 3000

const server = app.listen(PORT , (err) => {
  if(err)
console.log('Unable to start the server!')
else
console.log('Server started running on : ' + PORT)
})

module.exports=server;