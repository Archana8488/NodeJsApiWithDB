const express =  require('express');
const controller = require('../controller/controller')
const studController = require('../controller/studentcontroller')

const router = express.Router();

/**
 * @swagger
 *  /api/getAllData:
 *      get:
 *          tags:
 *          - Employees
 *          summary: Get user 
 *          description: Get all employee from the json file
 *          responses:
 *            200:
 *              description: List of employee
 *              schema:
 *                type: "array"
 *                items:
 *                 properties:
 *                  EmployeeID:
 *                      type:integer
 *                  Name:
 *                    type: string
 *                  City:
 *                    type: integer
 *                  Department:
 *                    type: integer
 *                  gender:
 *                    type: string
 *                  Gender:
 *                    type: string                
 *            401:
 *              description: Bad request.
 *            404:
 *              description: Not found.
 */
router.get('/api/getAllData', controller.getAllData);

/**
 * @swagger
 *  /api/addNewData:
 *      post:
 *          tags:
 *          - Employees
 *          summary: Add User
 *          description: Add user into json
 *          parameters:       
 *           - name: body
 *             in: body
 *             schema:
 *               type: object
 *               properties:
 *                Name:
 *                  type: string
 *                City:
 *                  type: string
 *                Department:
 *                  type: string
 *                Gender:
 *                  type: string     
 *          responses:
 *            200:
 *              description: Employee created successfully!
 *            404:
 *              description: No Found
 *            400:
 *              description: Bad request
 *            409:
 *              description: This employee already exists
 *            500:
 *              description: Internal Server Error.
 */

router.post('/api/addNewData',controller.addNewData);

/**
 * @swagger
 *  /api/updateData:
 *      put:
 *          tags:
 *          - Employees
 *          summary: Update User
 *          description: Add user into json
 *          parameters:       
 *           - name: body
 *             in: body
 *             schema:
 *               type: object
 *               properties:
 *                EmployeeID:
 *                    type:integer
 *                Name:
 *                  type: string
 *                City:
 *                  type: string
 *                Department:
 *                  type: string
 *                Gender:
 *                  type: string     
 *          responses:
 *            200:
 *              description: Employee created successfully!
 *            404:
 *              description: No Found
 *            400:
 *              description: Bad request
 *            409:
 *              description: This employee already exists
 *            500:
 *              description: Internal Server Error.
 */
router.put('/api/updateData',controller.updateData);

/**
 * @swagger
 *  /api/deleteData:
 *      delete:
 *          tags:
 *          - Employees
 *          summary: Add User
 *          description: Add user into json
 *          parameters:       
 *           - name: id
 *             in: body
 *             schema:
 *               type: object
 *               properties:
 *                EmployeeID:
 *                  type: integer   
 *          responses:
 *            200:
 *              description: Employee deleted successfully!
 *            404:
 *              description: No Found
 *            400:
 *              description: Bad request
 *            409:
 *              description: Some Error
 *            500:
 *              description: Internal Server Error.
 */
router.delete('/api/deleteData' , controller.deleteData);
router.get('/api/getAllStudent',studController.getAllStudent);

module.exports = router;